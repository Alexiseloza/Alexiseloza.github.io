webpackHotUpdate("static\\development\\pages\\index.js",{

/***/ "./componets/Eventos.js":
/*!******************************!*\
  !*** ./componets/Eventos.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _jsxFileName = "C:\\Users\\Argento Hosting\\Desktop\\BitcoinApp\\componets\\Eventos.js";


var Eventos = function Eventos(props) {
  var eventosId = object.key(props.eventos);
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: " list-group",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 7
    },
    __self: this
  });
};

/* harmony default export */ __webpack_exports__["default"] = (Eventos);

/***/ })

})
//# sourceMappingURL=index.js.90e767987fa254483a28.hot-update.js.map